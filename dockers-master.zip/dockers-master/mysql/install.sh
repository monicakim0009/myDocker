apt update -y
apt install -y vim
apt install -y python3
apt install -y python3-pip
ln -s /usr/bin/pip3 /usr/bin/pip
ln -s /usr/bin/python3 /usr/bin/python
